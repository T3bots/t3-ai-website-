// Example script, you can expand with animations or live form data later
console.log("T3 Website Loaded Successfully!");
